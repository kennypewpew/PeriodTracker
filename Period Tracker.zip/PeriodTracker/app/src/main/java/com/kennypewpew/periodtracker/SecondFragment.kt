package com.kennypewpew.periodtracker

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CalendarView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.kennypewpew.periodtracker.databinding.FragmentSecondBinding
import java.text.SimpleDateFormat
import java.util.*

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */

class SecondFragment : Fragment() {

    private var _binding: FragmentSecondBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.buttonSecond.setOnClickListener {
            //findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
            val v = view.findViewById(R.id.calendarView) as CalendarView
            val d = v.getDate()
            val msToDate = SimpleDateFormat("dd/MM/yyyy")
            val dd = msToDate.format(d)
            val toast = Toast.makeText(context, dd, Toast.LENGTH_SHORT)
            toast.show()
        }

        binding.setPeriodStart.setOnClickListener {
            val toast = Toast.makeText(context, "text", Toast.LENGTH_SHORT)
            //toast.show()
            val v = view.findViewById(R.id.calendarView) as CalendarView
            val d = v.getDate()
            v.setDate(d + 1000*60*60*24*3)
        }

        binding.setPeriodEnd.setOnClickListener {
            val toast = Toast.makeText(context, "text", Toast.LENGTH_SHORT)
            //toast.show()
            val v = view.findViewById(R.id.calendarView) as CalendarView
            val d = v.getDate()
            v.setDate(d - 1000*60*60*24*3)
        }


        binding.calendarView.setOnDateChangeListener(CalendarView.OnDateChangeListener { _, y, m, d ->
            val cal = Calendar.getInstance()
            cal.set(y,m,d)
            val msToDate = SimpleDateFormat("dd/MM/yyyy")
            val dateString = msToDate.format(cal.getTimeInMillis())
            val toast = Toast.makeText(context, dateString, Toast.LENGTH_SHORT)
            toast.show()
            val v = view.findViewById(R.id.calendarView) as CalendarView
            v.setDate(cal.getTimeInMillis())
        })
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}